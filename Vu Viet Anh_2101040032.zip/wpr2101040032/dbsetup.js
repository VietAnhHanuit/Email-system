const mysql2 = require('mysql2');

const connection = mysql2.createConnection({
  host: 'localhost',
  user: 'wpr',
  password: 'fit2024',
  port: 3306,
  database: 'wpr2101040047'
});

connection.connect((err) => {
  if (err) throw err;
  console.log('Connected');
});

const createUsersTable = `CREATE TABLE users(
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  password VARCHAR(50),
  email VARCHAR(50) 
);`;

const createEmailsTable = `CREATE TABLE emails(
  id INT AUTO_INCREMENT PRIMARY KEY,
  sender_id INT,
  receiver_id INT,
  message TEXT,
  send_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(sender_id) REFERENCES users(id),
  FOREIGN KEY(receiver_id) REFERENCES users(id)
);`;

const createFileAttachTable = `CREATE TABLE Attachments (
  id INT AUTO_INCREMENT,
  email_id INT,
  file LONGBLOB,
  PRIMARY KEY (id),
  FOREIGN KEY (email_id) REFERENCES Emails(id)
);
`;

connection.query(createUsersTable, (err, results) => {
  if (err) throw err;
  console.log('Users table created');
});

connection.query(createEmailsTable, (err, results) => {
  if (err) throw err;
  console.log('Emails table created');
});
connection.query(createFileAttachTable, (err, results) => {
  if (err) throw err;
  console.log('Attach table created');
});

const users = [
    {username: "admin", password: "123456", email: "a@a.com"}, 
    {username: "admin2", password: "123456", email: "b@b.com"}, 
    {username: "admin3", password: "123456", email: "c@c.com"}
];
users.forEach((user) => {
  connection.query('INSERT INTO users (username, password, email) values (?, ?, ?)', [user.username, user.password, user.email], (err, res) => {
    if(err) throw err;
    console.log('user inserted');
  });
});

const emails = [
  {sender_id: 1, receiver_id: 2, message: "Hello from a@a.com"},
  {sender_id: 1, receiver_id: 3, message: "Hello from a@a.com"},
  {sender_id: 2, receiver_id: 1, message: "Hello from b@b.com"},
  {sender_id: 3, receiver_id: 1, message: "Hello from c@c.com"},
  {sender_id: 2, receiver_id: 3, message: "Hello from b@b.com"},
  {sender_id: 3, receiver_id: 2, message: "Hello from c@c.com"},
  {sender_id: 2, receiver_id: 1, message: "Another message from b@b.com"},
  {sender_id: 3, receiver_id: 1, message: "Another message from c@c.com"}
];
emails.forEach((email) => {
  connection.query('INSERT INTO emails (sender_id, receiver_id, message) VALUES (?, ?, ?)', [email.sender_id, email.receiver_id, email.message], (err, res) => {
    if(err) throw err;
    console.log('email inserted');
  });
});

connection.end((err) => {
  if (err) throw err;
  console.log('Closed connection');
});
