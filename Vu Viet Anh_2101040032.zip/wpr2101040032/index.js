const express = require('express');
const mysql2 = require('mysql2');
const cookieParser = require('cookie-parser');
const path = require('path');
const multer = require('multer');
const fs = require('fs');

const connection = mysql2.createConnection({
    host: 'localhost',
    user: 'wpr',
    password: 'fit2024',
    port: 3306,
    database: 'wpr2101040047'
  });

require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 8001;
const upload = multer({ dest: 'uploads/' });

app.set('view engine', 'ejs');
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());


//check user Middleware
const verifyUser = (req, res, next) => {
    if(typeof req.cookies.user !== "undefined"){
        next();
    }
    else{
        res.redirect('/');
    }
}

app.get('/', (req, res)=>{
    res.render(path.join(__dirname, 'signin'));
});

app.post('/sign-in', (req, res)=>{
    const {username, password} = req.body;
    if (username == ""){
        res.render(path.join(__dirname, 'signin'), {emptyusername : "Username must not be empty"});
    }
    if (password == ""){
        res.render(path.join(__dirname, 'signin'), {emptypassword : "Password must not be empty"});
    }
    const query = 'SELECT * FROM users WHERE username = ? AND password = ?';
    const values = [username, password];
    new Promise((resolve, reject) =>{
        connection.query(query, values, (err, results) =>{
            if(err) reject(err);
            resolve(results);
        });
    })
    .then(results =>{
        if(results.length != 0){
            res.cookie('user', results[0]);
            res.redirect('inbox');
        } else{
            res.render(path.join(__dirname, 'signin'), {notvalid : "Username or Password is not correct"});
        }
    })
    .catch(err =>{
        console.log(err);
    });
});

app.get('/inbox', verifyUser, (req, res)=>{
    var user = req.cookies.user;
    const query = 'SELECT emails.id, emails.message, emails.sender_id , users.email as `from` FROM emails LEFT JOIN users ON emails.sender_id = users.id WHERE emails.receiver_id = ? ORDER BY emails.send_date;';
    const values = user.id;
    new Promise((resolve, reject) => {
        connection.query(query, values, (err, results) => {
            if(err) reject(err);
            resolve(results);
        });
    })
    .then(results => {
        res.render(path.join(__dirname, 'inbox'), {user : user, listmail : results});
    })
    .catch(err => {
        console.error(err);
    });
});

app.get('/outbox', verifyUser, (req, res)=>{
    var user = req.cookies.user;
    const query = 'SELECT emails.id, emails.message, emails.receiver_id, users.email as `to` FROM emails LEFT JOIN users ON emails.receiver_id = users.id WHERE emails.sender_id = ? ORDER BY emails.send_date;';
    const values = user.id;
    new Promise((resolve, reject) => {
        connection.query(query, values, (err, results) => {
            if(err) reject(err);
            resolve(results);
        });
    })
    .then(results => {
        res.render(path.join(__dirname, 'outbox'), {user : user, listmail : results});
    })
    .catch(err => {
        console.error(err);
    });
});

app.get('/pre-compose', verifyUser, (req, res)=>{
    var user = req.cookies.user;
    const query = 'SELECT * FROM users;';
    new Promise((resolve, reject) => {
        connection.query(query, (err, results) => {
            if(err) reject(err);
            resolve(results);
        });
    })
    .then(results => {
        res.render(path.join(__dirname, 'compose'), {lst_user : results});
    })
    .catch(err => {
        console.error(err);
    });
});

app.post('/compose', verifyUser, upload.array('file'), (req, res) =>{
    var user = req.cookies.user;
    const files = req.files;
    const query = 'INSERT INTO emails (sender_id, receiver_id, message) VALUES (?, ?, ?)';
    const values = [user.id, req.body.receiver_id, req.body.message];
    new Promise((resolve, reject) => {
        connection.query(query , values, (err, results) => {
            if(err) reject(err);
            resolve(results);
        });
    })
    .then(results => {
        if (files.length == 0){
            res.send("Ok");
        }
        const insertedid = results.insertId;
        files.forEach(f =>{
            const fileBuffer = fs.readFileSync(f.path);
            const query2 = 'INSERT INTO Attachments (email_Id, file) VALUES (?, ?);';
            const values2 = [insertedid, fileBuffer];
            new Promise((resolve, reject) => {
                connection.query(query2 , values2, (err, results) => {
                    if(err) reject(err);
                    resolve(results);
                });
            })
            .then(results => {
                res.send("OK");
            })
            .catch(err => {
                console.error(err);
            });
        });
    })
    .catch(err => {
        console.error(err);
    });
});

app.get('/detailin/:id', verifyUser, (req, res)=>{
    var user = req.cookies.user;
    const query = 'SELECT emails.id, emails.message, emails.sender_id, emails.send_date, users.email as `from` FROM users RIGHT JOIN emails ON emails.sender_id = users.id WHERE emails.id = ?;';
    const value = req.params.id;
    new Promise((resolve, reject) => {
        connection.query(query,value , (err, results) => {
            if(err) reject(err);
            resolve(results);
        });
    })
    .then(results => {
        const query2 = 'SELECT * FROM attachments WHERE email_id = ?';
        const values2 = req.params.id;
        new Promise((resolve, reject) => {
            connection.query(query2, values2, (err, results2)=>{
                if(err) reject(err);
                resolve(results2);
            });
        })
        .then(results2 => {
            results[0].lstfile = results2
            console.log(results[0]);
            res.render(path.join(__dirname, 'detailin'), {user : user, mail : results[0]});
        })
        .catch(err => {
            console.error(err);
        });
    })
    .catch(err => {
        console.error(err);
    });
});

app.get('/detailout/:id', verifyUser, (req, res)=>{
    var user = req.cookies.user;
    const query = 'SELECT emails.id, emails.message, emails.receiver_id, emails.send_date, users.email as `to` FROM users RIGHT JOIN emails ON emails.receiver_id = users.id WHERE emails.id = ?;';
    const value = req.params.id;
    new Promise((resolve, reject) => {
        connection.query(query,value , (err, results) => {
            if(err) reject(err);
            resolve(results);
        });
    })
    .then(results => {
        const query2 = 'SELECT * FROM attachments WHERE email_id = ?';
        const values2 = req.params.id;
        new Promise((resolve, reject) => {
            connection.query(query2, values2, (err, results2)=>{
                if(err) reject(err);
                resolve(results2);
            });
        })
        .then(results2 => {
            results[0].lstfile = results2
            console.log(results[0]);
            res.render(path.join(__dirname, 'detailout'), {user : user, mail : results[0]});
        })
        .catch(err => {
            console.error(err);
        });
    })
    .catch(err => {
        console.error(err);
    });
});

app.get('/download/:id', verifyUser, (req, res)=>{
    var user = req.cookies.user;
    const query = 'SELECT file FROM attachments WHERE id = ?';
    const value = req.params.id;
    new Promise((resolve, reject) => {
        connection.query(query,value , (err, results) => {
            if(err) reject(err);
            resolve(results);
        });
    })
    .then(results => {
        res.setHeader('Content-Type', 'application/octet-stream');
        res.setHeader('Content-Disposition', 'attachment');
        res.end(results[0].file);
    })
    .catch(err => {
        console.error(err);
    });
});

app.get('/log-out', verifyUser, (req, res) =>{
    res.clearCookie('user');
    res.redirect('/');
});

app.get('/sign-up-form', (req, res) =>{
    res.render(path.join(__dirname, 'signup'));
});
app.post('/sign-up', (req, res) => {
    const {username, email, password, confirmpassword} = req.body;

    if(password.length < 6){
        return res.render(path.join(__dirname, 'signup'), {passwordlengtherror : "password has at least 6 characters"});
    }
    if(password !== confirmpassword){
        return res.render(path.join(__dirname, 'signup'), {passwordmatcherror : "password does not match"});
    }
    
    const check_email = 'SELECT * FROM users WHERE email = ?';
    new Promise((resolve, reject) => {
        connection.query(check_email, email, (err, results) => {
            if(err) reject(err);
            resolve(results.length > 0);
        });
    })
    .then(emailExists => {
        if(emailExists){
            return res.render(path.join(__dirname, 'signup'), {existmailerror : "email has already existed"});
        }

        const check_username = 'SELECT * FROM users WHERE username = ?';
        return new Promise((resolve, reject) => {
            connection.query(check_username, username, (err, results) => {
                if(err) reject(err);
                resolve(results.length > 0);
            });
        });
    })
    .then(usernameExists => {
        if(usernameExists){
            return res.render(path.join(__dirname, 'signup'), {existusernameerror : "username has already existed"});
        }

        const insert_query = 'INSERT INTO users(username, password, email) VALUES (?, ?, ?)';
        const values = [username, password, email];
        connection.query(insert_query, values , (err, results) =>{
            if(err) throw err;
            return res.redirect('/');
        });
    })
    .catch(err => {
        // Handle error
        console.error(err);
    });
});

app.listen(PORT, ()=>{
    console.log(`http://localhost:${PORT}`)
})

